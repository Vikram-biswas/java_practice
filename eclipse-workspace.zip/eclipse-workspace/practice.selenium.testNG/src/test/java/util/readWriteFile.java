package util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class readWriteFile extends list {
	
	public static void main(String args[]) {
		

	}

	public static void fileReader() {
		String file = "./vikram.txt";
		try (FileReader fileReader = new FileReader(file); BufferedReader reader = new BufferedReader(fileReader)) {
			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void fileWriter() {
		String file = "./vikram123.txt";
		String content = "Hello Vikram";
		try (FileWriter fle = new FileWriter(file)) {
			fle.write(content);
			System.out.println("File created successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	

}
