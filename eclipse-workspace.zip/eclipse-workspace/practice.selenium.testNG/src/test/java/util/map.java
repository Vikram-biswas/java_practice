package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class map {
	static HashMap<Object,Object> map = new HashMap<Object, Object>();
	static HashMap<Object,Object> map2 = new HashMap<Object, Object>();
	static{
		map.put("name1", "vikram");
		map.put("age", 30);
		map.put("Height", 5.5);
		map.put("complexion", "brown");
		map.put("weight", 87);
		map.put("name2", "vikram");
	}
	
	public static void main(String[] args) {
		keyExistinMap();

	}
	
	//Question: Find Duplicate Characters using stream methods
	public static void findDuplicate1() {
		Map<Object, Object> map1 = map.entrySet().stream().collect(Collectors.groupingBy(Map.Entry::getValue,Collectors.counting())).entrySet().stream().filter(entry-> entry.getValue()>1).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		map1.forEach((key,value)-> System.out.println("key is "+key +" and value is "+value));
	}
	
	
	//Question: Find Duplicate Characters without using stream methods
	public static void findDuplicate2() {
		List<Object> map1 = new ArrayList<Object>();
		for(Map.Entry<Object, Object> val:map.entrySet()) {
			if(!map1.contains(val.getValue())){
				map1.add(val.getValue());
				map2.put(val.getKey(), val.getValue());
			}
		}
		map2.forEach((key,value) -> System.out.println(" key is "+key+ " and value is "+ value));
	}
	
	//Coding question on key exists or not using hashmap
    public static void keyExistinMap() {
    	boolean flag = false;
    	for(Map.Entry<Object, Object> val:map.entrySet()) {
    		if(val.getKey().equals("name1")) {
    			flag = true;
    		}
    	}
    	
    	System.out.println(flag);
    	
    	String name = "vikram".trim().concat("Biswas".replace("Biswas", "BISWAS"));
    	System.out.println(name);
    
    }
	
}
