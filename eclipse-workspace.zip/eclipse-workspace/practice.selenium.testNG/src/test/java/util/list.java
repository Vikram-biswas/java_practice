package util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class list {
	static List<Integer> lst = Arrays.asList(3,2,1,6,5,2,1);
	static List<Integer> lst1 = Arrays.asList(9,7,8,9,6);
	static int i = lst.size()-1;
	static List<Integer> reverse = new ArrayList<>();
	
	public static void main(String argss[]) {
		reverseList();
	}

	
	//Reverse a List using steamAPI
	public static void reverseList() {
		List<Integer> strm = lst.stream().sorted((a,b)-> b.compareTo(a)).collect(Collectors.toList());
		System.out.println(strm);
		
	}
	
	
	//reverse a list using collections
	public static void reverse() {
		Collections.reverse(lst);
		System.out.println(lst);
	}
	
	
	//reverse list without using any inbuild method
	public static void reverse1() {
		List<Integer> reverse = new ArrayList<>();
		for(int i=lst.size()-1;i>=0;i--) {
			reverse.add(lst.get(i));
		}
		System.out.println(reverse);
	}
	
	// reverse list with using do while
	public static void reverse2() {
		List<Integer> reverse = new ArrayList<>();
		int i = lst.size()-1;
		do {
			reverse.add(lst.get(i));
			i--;
		}while(i>=0);
		System.out.println(reverse);
	}
	
	// reverse a list with recursive method
	public static void reverse3() {
		if(i>=0) {
			reverse.add(lst.get(i));
			i--;
			reverse3();
		}else {
			System.out.println(reverse);
		}		
	}
	
	//Question: Find Duplicate Elements
	public static void findDuplicate1() {
		
		List<Integer> val = lst.stream().collect(Collectors.groupingBy(i->i,Collectors.counting())).entrySet().stream().filter(entry -> entry.getValue()>1).map(Map.Entry::getKey).collect(Collectors.toList());
		System.out.println(val);		
	}
	
	//Question: Count Occurrences of Elements
	public static void findOccurance() {
		Map<Object, Long> val = lst.stream().collect(Collectors.groupingBy(i->i,Collectors.counting()));
		val.forEach((key,value) -> System.out.println(key+ "occurs"+value));
		
	}
	
	//Question: Remove Duplicates using stream API
	public static void removeDuplicates() {
		List<Integer> val =lst.stream().distinct().collect(Collectors.toList());
		System.out.println(val);
	}
	
	//Question: Remove Duplicates
	public static void  removeDuplicates1() {
		
		for(int val:lst) {
			if(!reverse.contains(val)) {
				reverse.add(val);
			}
		}
		System.out.println(reverse);
	}
	
	//Question: Sort Elements
	public static void sortElements() {
		Collections.sort(lst);
		System.out.println(lst);
	}
	
	//Question: Sort Elements using stream API
	public static void sortelement() {
		reverse = lst.stream().sorted().collect(Collectors.toList());
		System.out.println(reverse);
	}
	
	
	//Question: Merge Two Lists
	public static void mergeLists() {
		LinkedList<Integer> output = new LinkedList<Integer>(lst);
		for(int i=0;i<lst1.size();i++) {
			output.add(lst1.get(i));
		}
		System.out.println(output);
	}
	
	// Question: merge two lists using stream API
	public static void mergelist() {
		List<Integer> output = Stream.concat(lst.stream(), lst.stream()).collect(Collectors.toList());
		System.out.println(output);
	}

	//Question: Intersection of Lists
	public static void intersectionLists() {
		List<Integer> output = lst.stream().filter(lst1::contains).collect(Collectors.toList());
		System.out.println(output);
	}
	
	
}
