package util;

public class pojoClass {

	private String name;
	private int id;
	private int height;
	private int weight;
	private String maritalStatus;

	pojoClass(String name, int id, int height, int weight, String maritalStatus) {
		this.name = name;
		this.id = id;
		this.height = height;
		this.weight = weight;
		this.maritalStatus = maritalStatus;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	public int getHeight() {
		return height;
	}

	public int getWeight() {
		return weight;
	}

	public String getmaritalStatus() {
		return maritalStatus;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}

	public void setId(int id) {
		this.id =  id;
	}

	public void setHeight(int height) {
		this.height =  height;
	}

	public void setWeight(int weight) {
		this.weight =  weight;
	}

	public void setmaritalStatus(String maritalStatus) {
		this.maritalStatus =  maritalStatus;
	}

}
