package util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class programPractice {
	
	public static void main(String[] args) {

		calculateAverageOfOneObjectProperty();

	}
	
	static void arrangeListWithStringLength() {		
		String[] array = {"vikram","madhuri","haji","son","sohan","bo"};
		Map<Integer,String> maps = new HashMap<Integer,String>();
		for(String val:array) {
			int len = val.length();
			maps.put(len, val);
		}
		//Map<Integer,String> sortedMap = maps.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,(oldValue,newvalue)-> oldValue,HashMap::new));
		
		Map<Integer,String> sortedMap = maps.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(LinkedHashMap::new,(a,b)->a.put(b.getKey(),b.getValue()),Map::putAll);
		//sortedMap.forEach((key,value)-> System.out.println(key+" "+value));
		
		
		sortedMap.forEach((key,value) -> System.out.println(key+""+value));
	}

	
	 //Write a class, create objects, keep objects in a list and filter the list by one object property
	static void filterObjectsByInput() {
		
		pojoClass obj1 = new pojoClass("Vikram",1,6,87,"Married");
		pojoClass obj2 = new pojoClass("Madhuri",2,5,55,"Married");
		List<pojoClass> obj = new ArrayList<>();
		obj.add(obj1);
		obj.add(obj2);
		String filterWith = "Madhuri";
		
		List<pojoClass> filers = obj.stream().filter(obj3-> obj3.getName().equals(filterWith)).collect(Collectors.toList());
		
		for(pojoClass obj3:filers) {
			System.out.println(obj3.getName()+" "+obj3.getId()+" "+obj3.getmaritalStatus());
		}
		
	}
	
	
	//Write a class, create objects, keep objects in map and iterate through it and calculate average of one object property
	static void calculateAverageOfOneObjectProperty() {
		
		pojoClass obj1 = new pojoClass("Vikram",1,6,87,"Married");
		pojoClass obj2 = new pojoClass("Madhuri",2,5,55,"Married");
		
		int sum = 0;
		
		Map<Integer,pojoClass> myMap = new HashMap<>();
		myMap.put(obj1.getId(), obj1);
		myMap.put(obj2.getId(), obj2);
		
		
		for(Map.Entry<Integer, pojoClass> entry:myMap.entrySet()) {
			sum = sum+ entry.getValue().getId();
		}
		
		double average = (double) sum/myMap.size();
		System.out.println(average);
		
		
	}
	
	
	
}
