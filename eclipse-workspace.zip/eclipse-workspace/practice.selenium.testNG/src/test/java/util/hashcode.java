package util;

import java.util.Objects;

public class hashcode {
	 private String title;
	    private String author;
	    private int year;

	    public hashcode(String title, String author, int year) {
	         this.title = title;
	        this.author = author;
	        this.year = year;
	    }

	    @Override
	    public int hashCode() {
	        return Objects.hash(title, author, year);
	    }

	    // Getters and setters (omitted for brevity)

	    public static void main(String[] args) {
	    	hashcode book1 = new hashcode("Java Fundamentals", "John Doe", 2020);
	    	hashcode book2 = new hashcode("Java Fundamentals", "John Doe", 2020);

	        // Printing hash codes
	        System.out.println("Hash code of book1: " + book1.hashCode());
	        System.out.println("Hash code of book2: " + book2.hashCode());

	        // Comparing equality using hashCode
	        System.out.println("Are book1 and book2 equal? " + (book1.hashCode() == book2.hashCode()));
	    }
}
