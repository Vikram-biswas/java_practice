package util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.bouncycastle.operator.OutputAEADEncryptor;

public class streamAPI {
	
	static List<String> list = new ArrayList<>();
	static Map<String, String> map = new HashMap<>();
	

	public static void main(String[] args) {
		
    //	assigned map values	
		list.add("Vikram");
		list.add("Madhuri");
		list.add("Vikram");
		list.add("Samaddar");
		
	//	assigned map values
		
		map.put("name", "vikram");
		map.put("age", "31");
		map.put("height", "5.5");
		map.put("gender", "male");
		sortListusingLength();
       
	}
	
	
	//sort lists using stream
	public static void sortList() {
		List<String> sortedList = list.stream().sorted((a,b)->b.compareTo(a)).collect(Collectors.toList());
		System.out.println(sortedList);		
	}
	
	//sort maps using stream
	public static void sortmaps() {
		Map<String, String> sortedMap = map.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(LinkedHashMap::new, (a,b)->a.put(b.getKey(),b.getValue()),Map::putAll);
		sortedMap.forEach((key,value)-> System.out.println(key+" "+ value));
	}
	
	//filter from objects
	public static void filterFromObjects() {
		String marritalStatus = "Married";
		pojoClass pojo1 = new pojoClass("vikram",1,6,87,"Married");
		pojoClass pojo2 = new pojoClass("madhuri",1,6,87,"Married");
		List<pojoClass> pojo = new ArrayList<>();
		pojo.add(pojo1);
		pojo.add(pojo2);
		List<pojoClass> ouput = pojo.stream().filter(obj -> obj.getmaritalStatus().equals(marritalStatus)).collect(Collectors.toList());
		ouput.forEach((val) -> System.out.println(val.getName()));

	}

	//filter from maps
	public static void filterFromMaps() {
		String name = "vikram";
		Map<String, String> sortedMap = map.entrySet().stream().filter(obj->obj.getValue().equals(name)).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));		
		sortedMap.forEach((key,value)-> System.out.println(key+" "+value));
		
	}
	
	//sort list using length
	
	static void sortListusingLength() {
		
		String value = "HI vikram, I want you in project, are you in bench";
		String[] arr = value.replace(",", "").split(" ");
		List<String> list = Arrays.asList(arr);
		List<String> val = list.stream().sorted(Comparator.comparingInt(String::length)).toList();
		val.forEach(System.out::println);

		
	}
	
	
	
	
	public static void sortingUsingComparator() {
		//<Integer> obj = new Comparator<Integer>();

	}
	
	
	
	
	
	
	
	
}
 