package util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class practice {
	
	
	public static void main(String args[]) {
		
		if(keyExists(2)) {
			System.out.println("key exist!");
		}
		
	}
	
	
	//sorting objects
	
	public static void sortingObjects() {
		pojoClass obj1 = new pojoClass("Vikram",4,6,80,"Married");
		pojoClass obj2 = new pojoClass("Madhuri",2,6,80,"Married");
		List<pojoClass> obj = new ArrayList<>();
		obj.add(obj1);
		obj.add(obj2);
		
		//List<pojoClass> output = obj.stream().sorted((a,b)->b.compare(a)).collect(Collectors.toList());
		Collections.sort(obj,Comparator.comparing(pojoClass::getId));
		
		for(pojoClass val:obj) {
			System.out.println(val.getName());
		}
	}
	
	
	//Coding question on key exists or not using hashmap
	
	public static void ifKeyExists(int input) {
		boolean flag = true;
		Map<Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "Vikram");
		map.put(2, "madhuri");
		map.put(3, "biswas");
		
		for(Map.Entry<Integer, String> entry:map.entrySet()) {
			if(entry.getKey()==input) {
				System.out.println("key exist!");
				flag = false;
				break;
			}
		}
		
		if(flag) {
			System.out.println("key doesn't exist!");
		}
		
		
	}
	
	//Coding question on key exists or not using stream
	
	public static boolean keyExists(int input) {
		Map<Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "Vikram");
		map.put(2, "madhuri");
		map.put(3, "biswas");
		
		boolean flag = map.entrySet().stream().anyMatch(key -> key.getKey().equals(input));
		
		return flag;
		
	}
	
	
	

	

}
