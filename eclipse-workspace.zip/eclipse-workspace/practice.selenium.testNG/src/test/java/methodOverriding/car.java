package methodOverriding;

public class car extends vehicle{
	@Override
	public void weels() {
		System.out.println("car have 4 weels");
	}
	
}
