package methodOverriding;

public class vehicle {

	public void weels() {
		System.out.println("No of weels");
	}

}
