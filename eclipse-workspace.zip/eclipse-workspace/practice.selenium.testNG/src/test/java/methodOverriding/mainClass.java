package methodOverriding;

public class mainClass {

	public static void main(String[] args) {
		vehicle car = new car();
		vehicle bus = new bus();
		car.weels();
		bus.weels();

	}

}
