package methodOverriding;

public class bus extends vehicle{
	@Override
	public void weels() {
		System.out.println("bus have 8 weels");
	}
	
}
