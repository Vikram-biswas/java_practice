package testNG.tests;

import org.testng.annotations.Test;

public class gmail {
	
	@Test
	public void test() {
		
		
		
	}

}
