package testNG.tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class chatGPT extends utility{
	

	@Test
	public void test() {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'Up to 55% off')]/parent::div/following-sibling::div//span[text()='Microwaves']")));    
    WebElement element = driver.findElement(By.xpath("//h2[contains(text(),'Up to 55% off')]/parent::div/following-sibling::div//span[text()='Microwaves']"));
    element.click();
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Samsung 21L')]"))); 
    driver.quit();
    
	}
}
