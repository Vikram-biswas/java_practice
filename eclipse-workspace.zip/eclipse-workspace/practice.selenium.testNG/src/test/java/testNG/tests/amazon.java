package testNG.tests;

import org.testng.annotations.Test;

public class amazon extends util.practice{
	

}
