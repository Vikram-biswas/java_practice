package lambdaExpression;

public interface testInterface {

	void print();
}
