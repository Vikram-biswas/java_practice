package lambdaExpression;

public class mainClass{

	public static void main(String[] args) {
		
		testInterface obj = ()-> {
				System.out.println("vikram");
		};
      obj.print();
		
	}

}
