package singletonPattern;

public class mailClass {

	public static void main(String[] args) {
     class1 obj123 = class1.getInstance();
     class1 obj13 = class1.getInstance();
     class1 obj134 = class1.getInstance();
	}

}
