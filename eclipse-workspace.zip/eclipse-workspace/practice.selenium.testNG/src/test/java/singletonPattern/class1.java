package singletonPattern;

public class class1 {

static class1 obj;

class1(){
	System.out.println("Hi, Vikram");
}
 static class1 getInstance() {
	 if(obj==null) {
		 obj = new class1();
	 }
	 return obj;
 }
}
