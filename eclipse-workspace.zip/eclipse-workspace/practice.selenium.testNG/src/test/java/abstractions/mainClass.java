package abstractions;

public class mainClass {
	
	public static void main(String[] args) {
		
		account acc = new savingAccount();
		acc.deposit(500);
		acc.withdraw(100);

	}

}
