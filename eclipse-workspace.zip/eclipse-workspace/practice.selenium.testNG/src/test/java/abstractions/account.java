package abstractions;

interface account {
	void deposit(int amount);
	void withdraw(int amount);
	void getBalance();
}
