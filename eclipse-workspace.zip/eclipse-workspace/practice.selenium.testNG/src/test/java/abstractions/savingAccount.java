package abstractions;

public class savingAccount implements account{
	private double balance;
	
	public void deposit(int amount) {
		this.balance+=amount;
		System.out.println("Current balance is "+this.balance);
	}
	public void withdraw(int amount) {
	if(this.balance>amount) {
		this.balance-=amount;
		System.out.println("Current balance is "+this.balance);
	}
	}
	
    public void getBalance() {
    	System.out.println(this.balance );
    }
}
