package pojoClasses;

public class createUserResponse {
	
	private String name;
	private String job;
	private String id;
	private String createdAt;
	
	
	public String getname() {
		return name;
	}
	
	public String getjob() {
		return job;
	}
	
	public String getid() {
		return id;
	}
	
	public String getcreatedAt() {
		return createdAt;
	}

	public void setname(String value) {
		this.name = value;
	}
	
	public void setjob(String value) {
		this.job = value;
	}
	
	public void setid(String value) {
		this.id = value;
	}
	
	public void setcreatedAt(String value) {
		this.createdAt = value;
	}
	
	
}
