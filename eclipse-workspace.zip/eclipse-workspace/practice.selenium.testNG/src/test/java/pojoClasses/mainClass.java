package pojoClasses;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import com.google.gson.Gson;

public class mainClass {

	public static void main(String[] args) {
		RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1/create";
         createUserRequest obj = new createUserRequest();
         obj.setname("vikram");
         obj.setsalary("123");
         obj.setage("23");
         
         Gson bdy = new Gson();
         String payload = bdy.toJson(obj);
         Response res = given().contentType("application/json").body(payload).when().post().then().extract().response();
         //createUserResponse objRes = res.as(createUserResponse.class);
         //System.out.println(objRes.getname());
         System.out.println(res.asString());
	}

}
