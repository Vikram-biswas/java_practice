package pojoClasses;

public class createUserRequest {
	
	private String name;
	private String salary;
	private String age;
	
	public String getname() {
		return name;
	}
	
	public String getsalary() {
		return salary;
	}
	
	public String getage() {
		return age;
	}


	public void setname(String value) {
		this.name = value;
	}
	
	public void setsalary(String value) {
		this.salary = value;
	}
	
	public void setage(String value) {
		this.age = value;
	}
	
	
}
