package pageObjects;

public class amazonPage {

}
