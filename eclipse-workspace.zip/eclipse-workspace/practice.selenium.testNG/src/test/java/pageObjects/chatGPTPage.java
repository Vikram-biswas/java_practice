package pageObjects;

public class chatGPTPage {
	public final static String url = "https://www.amazon.in/";
	public final static String textBox_id = "prompt-textarea";
}
