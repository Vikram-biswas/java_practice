package pageObjects;

public class gmailPage {

}
