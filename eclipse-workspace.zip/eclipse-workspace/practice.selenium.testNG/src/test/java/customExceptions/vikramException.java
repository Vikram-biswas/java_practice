package customExceptions;

@SuppressWarnings("serial")
public class vikramException extends Exception{

	vikramException(String msg){
		super(msg);
	}
}
