package customExceptions;

public class mainClass{
	

	public static void main(String a[]) throws vikramException {

		String[] arr = new String[1];
		for (int i = 0; i < 5; i++) {
			arr[i] = "vikram";
			throw new vikramException("this is my arrayOutOfBound exception");
		}
			
	}

}
