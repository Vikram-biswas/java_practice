package factoryDesign;

public class Ios implements OS{
public void specs() {
	System.out.println("This is IOS");
}
}
