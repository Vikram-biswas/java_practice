package factoryDesign;

public class Windows implements OS {

	public void specs() {
		System.out.println("This is Windows");
	}
}
