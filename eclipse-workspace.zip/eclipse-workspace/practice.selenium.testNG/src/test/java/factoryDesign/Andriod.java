package factoryDesign;

public class Andriod implements OS  {

	public void specs() {
		System.out.println("this is andriod");
	}
	
}
