package factoryDesign;

public interface OS {
	void specs();

}
