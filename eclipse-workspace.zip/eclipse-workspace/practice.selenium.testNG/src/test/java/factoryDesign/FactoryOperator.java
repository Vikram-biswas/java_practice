package factoryDesign;

public class FactoryOperator {
	
	public OS getInstance(String os) {
		if(os.equals("openSource")) {
			return new Andriod();
		}else if(os.equals("secured")) {
			return new Ios();
		}else {
			return new Windows();
		}
		
		
	}

}
