package factoryDesign;

public class FactoryMain {

	public static void main(String[] args) {
		
		FactoryOperator obj = new FactoryOperator();
		OS ob = obj.getInstance("openSource");
        ob.specs();
	}

}
