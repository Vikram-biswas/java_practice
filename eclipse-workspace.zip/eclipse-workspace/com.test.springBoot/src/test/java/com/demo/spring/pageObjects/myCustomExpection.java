package com.demo.spring.pageObjects;

public class myCustomExpection extends Exception{
	
	

}
