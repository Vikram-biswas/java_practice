package com.demo.spring;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
public class baseClass {
	WebDriver driver;

	homeScreen home;
	

	loginScreen login;

	public baseClass(homeScreen home, loginScreen login) {
		super();
		this.home = home;
		this.login = login;
	}
	
    @PostConstruct
    public void initDriver() {
    	driver = new FirefoxDriver();
    	PageFactory.initElements(driver, baseClass.this);
    }
	
	public void perform() {
		driver.get("https://practicetestautomation.com/practice-test-login/");
		login.login("student", "Password123");
	}
    
	

}
