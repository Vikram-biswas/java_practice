package com.demo.spring;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.stereotype.Component;

@Component
public class loginScreen{
	
	@FindBy(id="username") WebElement username;
	@FindBy(id="password") WebElement password;
	@FindBy(id="submit") WebElement submit;
	
	
	public void login(String user, String pass) {
		username.sendKeys(user);
		password.sendKeys(pass);
		submit.click();
	}

}
