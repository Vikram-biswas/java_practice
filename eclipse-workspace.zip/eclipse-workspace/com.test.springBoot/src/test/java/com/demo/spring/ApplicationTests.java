package com.demo.spring;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

import jakarta.annotation.PostConstruct;


@SpringBootTest
class ApplicationTests {

	@Autowired
	public baseClass base;

	
	@Test
	void contextLoads() {
		
		
//		driver.get("https://practicetestautomation.com/practice-test-login/");
//		base.login.login("student", "Password123");
//		if(base.home.validateLogoutLink()) {
//			
//		}
		base.perform();
		
		
	}

}
