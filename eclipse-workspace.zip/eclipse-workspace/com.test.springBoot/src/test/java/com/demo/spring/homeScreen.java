package com.demo.spring;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.stereotype.Component;

@Component
public class homeScreen{
	
	
	@FindBy(linkText="Log out") WebElement logout;
	
	
	public boolean validateLogoutLink() {
		boolean flag = false;
		if(logout.isDisplayed()) {
			flag = true;
			String value = logout.getText();
		}
		return flag;
	}
}
