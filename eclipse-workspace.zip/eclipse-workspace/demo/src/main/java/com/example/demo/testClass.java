package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public class testClass {

	@Autowired
	private test123 test123;
	
	

	public test123 getTest123() {
		return test123;
	}



	public void setTest123(test123 test123) {
		this.test123 = test123;
	}




}
