package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class test123 {
	
	public test123(String msg) {
		System.out.println("hello ........"+msg);
	}

}
