package tests;

import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.test.pageObject.productScreenPage;


@Listeners(ItestListner.class)
public class testsClass {
	WebDriver driver;

//	@Test
//	public void launchAmazon() {
//		// driver = startBrowser("https://www.amazon.in/");
//	}

	@DataProvider(name="UserDetails")
	public Object[][] dataProvider(){
		return new Object[][] {
			{"username1","vikram"},
			{"username2","biswas"}
			
		};
	}
	
	
	@Test(dataProvider = "UserDetails")
	public void data(String key, String value) {
		System.out.println(key+" "+value);
	}
	
	
	@Test(retryAnalyzer = Analyzer.class, threadPoolSize=1, invocationCount=1)
	public void addProductToCard() throws Exception {
		try {
			driver = utilityClass.startBrowser("https://www.amazon.in/");
			productScreenPage productPage = PageFactory.initElements(driver, productScreenPage.class);
			if (productPage.homePageVerification()) {
				List<WebElement> elements = productPage.productsCategoryList();		
				for(int i=0;i<elements.size();i++) {
					if(elements.get(0).getText().equals("Clothing")) {
						productPage.CategorySelection().click();
						break;
					}
				}		
				productPage.productSelection().click();
				productPage.sortByFilter().click();
				productPage.featuredFilter().click();
				List<String> value = new ArrayList<String>();
				List<WebElement> elements1 = productPage.limitedDealProductsList();	
				for(WebElement val:elements1) {
					value.add(val.getText());
				}
				Collections.sort(value);
				String prnt = productScreenPage.cheapProduct.replace("?", value.get(0));
				driver.findElement(By.xpath(prnt)).click();
				Set<String> windows = driver.getWindowHandles();
				String getDestinationWindow = (String) windows.toArray()[1];
				driver.switchTo().window(getDestinationWindow);
				productPage.addToCart().click();
				if(productPage.productAddedInCartSuccessMsg().isDisplayed()) {
					System.out.println("execution success");
				}
				driver.switchTo().defaultContent();
				
				
				
			}
			
		} catch (Exception e) {
            throw e;
		}

	}

	@Test
	public void closeApplication() {
		driver.quit();
	}

}
