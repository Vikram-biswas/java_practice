package tests;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Analyzer implements IRetryAnalyzer{
	
	int retryCount = 0;
	int Max_retryCount = 3;
	
	public boolean retry(ITestResult result) {
		
		if(retryCount<=Max_retryCount) {
			retryCount++;
			return true;
		}
		
		return false;
		
	}
	

}
