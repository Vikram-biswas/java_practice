package tests;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

public class ItestListner extends TestListenerAdapter  {
	
	public void onTestStart(ITestResult result) {
		System.out.println("Method started :: "+result.getName());
	}
	
	public void onTestSuccess(ITestResult result) {
		System.out.println("Method success :: "+result.getName());
	}
	
	public void onTestFailure(ITestResult result) {
		System.out.println("Method failed :: "+result.getName());
	}
	
	public void onTestskipped(ITestResult result) {
		System.out.println("Method skipped :: "+result.getName());
	}
}
