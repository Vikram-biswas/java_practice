package com.test.pageObject;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class productScreenPage {
	
	WebDriver driver;
	
	public productScreenPage(WebDriver drvr) {
		this.driver = drvr;
	}

	@FindBy(xpath="//span[text()='Hello, sign in']") public WebElement signIn;
	@FindBy(xpath="//h2[text()='Up to 60% off | Styles for men']/parent::div/following-sibling::div[1]//span") List<WebElement> productsCategoryList;
	@FindBy(xpath="//h2[text()='Up to 60% off | Styles for men']/parent::div/following-sibling::div[1]//span[text()='Clothing']") WebElement CategorySelection;
	@FindBy(xpath="//span[text()='Winter wear']") WebElement productSelection;
	@FindBy(xpath="//span[text()='Featured']") WebElement sortByFilter;
	@FindBy(linkText="Featured") WebElement featuredFilter;
	@FindBy(xpath="//span[text()='Limited time deal']/ancestor::div[2]/child::div[2]//span/span[2]") List<WebElement> limitedDealProductsList;
	@FindBy(id="add-to-cart-button") WebElement addToCart;
	@FindBy(id="NATC_SMART_WAGON_CONF_MSG_SUCCESS") WebElement productAddedInCartSuccessMsg;
	
	public static String cheapProduct = "//span[text()='Limited time deal']/ancestor::div[2]/child::div[2]//span/span[text()='?']";
	
	public WebElement signIn() {	
        return signIn;
    }
	
	public List<WebElement> productsCategoryList() {	
        return productsCategoryList;
    }
	
	
	public WebElement CategorySelection() {	
        return CategorySelection;
    }
	
	public WebElement productSelection() {	
        return productSelection;
    }
	
	public WebElement sortByFilter() {	
        return sortByFilter;
    }
	
	public WebElement featuredFilter() {	
        return featuredFilter;
    }
	
	public List<WebElement> limitedDealProductsList() {	
        return limitedDealProductsList;
    }
	
	
	public WebElement addToCart() {	
        return addToCart;
    }
	
	public WebElement productAddedInCartSuccessMsg() {	
        return productAddedInCartSuccessMsg;
    }
	
	public boolean homePageVerification() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));		
		wait.until(ExpectedConditions.visibilityOf(signIn()));
		return true;
	}
	
	
	
	
	
}
