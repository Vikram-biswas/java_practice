package dependencyInjection;

public interface Injection {
	
	public void test();

}
