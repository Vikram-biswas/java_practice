package dependencyInjection;

public class Main {
	
	Injection inj = new Child();
	
	
	public static void main(String[] args) {
	
    
		
	}
	

	
	

}
