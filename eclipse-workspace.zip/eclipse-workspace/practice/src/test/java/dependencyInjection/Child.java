package dependencyInjection;

public class Child implements Injection{
	
	public void test() {
		System.out.println("child");
	}

}
