package dependencyInjection;

public class Parent{
	
	public void test() {
		
		Child ch = new Child();
		ch.test();
		System.out.println("Parent");
	}

}
