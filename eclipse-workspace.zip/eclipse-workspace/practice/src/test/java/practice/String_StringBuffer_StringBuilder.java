package practice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class String_StringBuffer_StringBuilder {

	public static void main(String[] args) {
		String val = "Hello Vikram How are you";
		String input = "Vikram";
//		StringBuffer sb = new StringBuffer("VIkram");
//		System.out.println(sb.delete(0, sb.length()).append("Biswas"));
//		
//		
//		String name = "Vikram,";
//		String name1 = name.concat(" Biswas");
//		System.out.println(name1);
//		
		
		Pattern p = Pattern.compile(input);
		Matcher m = p.matcher(val);
		
		if(m.find()) {
			System.out.println(m.group());
		}else {
			System.out.println("matches not found");
		}
		
		
		
		
		
		
		
	}

}
