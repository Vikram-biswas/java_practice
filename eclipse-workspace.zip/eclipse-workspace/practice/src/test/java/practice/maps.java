package practice;

import java.util.HashMap;
import java.util.Map;

public class maps {
	
	public static void main(String a[]) {
		Map<String, String> map = new HashMap<>();
		
	}

}
