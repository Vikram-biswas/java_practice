package practice;

public class prime {

	public static void main(String a[]) {
		
		isPrime(19);
		
	}
	
	
	static void isPrime(int number) {
		boolean isPrime = true;
		
		for(int factor=2;factor<=number/2;factor++) {
			if(number%factor==0) {
				isPrime = false;
				break;
			}
		
		}
		if(isPrime) {
			System.out.println("number is Prime");
		}else {
			System.out.println("number is not Prime");
		}
	}
	
	
}
