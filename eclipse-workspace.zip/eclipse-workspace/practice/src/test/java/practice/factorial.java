package practice;

public class factorial {
	
	
	public static void main(String a[]) {
		
		factorials(9);
		
	}
	
	
	static void factorials(int number) {
		
		int fact = 1;
		
		for(int i =number;i>0;i--) {
			fact = fact*i;
		}
		System.out.println(fact);
		
	}
	

}
