package pojoClass;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.mapper.ObjectMapper;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class mainClass {
	
	static pojo pj1 = new pojo(1,"vikram",8790416550L,"12345","Hyderabad");
	static pojo pj2 = new pojo(2,"biswas",9674526097L,"61233","Hyderabad");
	static pojo pj3 = new pojo(3,"madhuri",9652746097L,"51213","Hyderabad");
	static pojo pj4 = new pojo(4,"samaddar",9989841355L,"12623","Hyderabad");
	static pojo pj5 = new pojo(5,"jagadesh",8998338013L,"834534","Hyderabad");
	static pojo pj6 = new pojo(6,"reddy",8790416511L,"945642","Hyderabad");
	static List<pojo> list = Arrays.asList(pj1,pj2,pj3,pj4,pj5,pj6);

	
	static String numberString = "10 39 40 12 14 60";
	
	public static void main(String args[]) {
		
		submitPostRequestPojoPayload();
		
		
	}
	
	//Write a class, create objects, keep objects in a Map, iterate through it and calculate average of one object property
	static public void calculateObjectByOneProperty() {
		int sum = 0;
		
		Map<Integer, pojo> map = new HashMap<>();
		for(pojo val:list) {
			map.put(val.id(), val);
		}	
		
		for(Map.Entry<Integer, pojo> mpp: map.entrySet()) {
			sum += mpp.getValue().id();
		}
		
		double average = (double) sum/map.size();
		System.out.println(average);
		
	}
	
	
	//Write a class, create objects and add those to a list, sort the list by one object property
	
	static public void sortObjectsByOneProperty() {
		
		Collections.sort(list, Comparator.comparing(pojo::name));
		list.forEach(val -> System.out.println(val.name()));
		
	}
	
	
	
	//Calculate the sum of space separated numbers in a string
	static public void sumOfSpaceSeperatedNumberInString() {
		String[] arr = numberString.split(" ");
		int[] arr1 = new int[arr.length];
		int sum = 0;
		for(int i=0;i<arr.length;i++) {
			arr1[i] = Integer.parseInt(arr[i]);
			sum+=arr1[i];
		}
		System.out.println(sum);
		
	}
	
	
	//Write code to submit a POST request using a POJO as payload
	static public void submitPostRequestPojoPayload() {
		RestAssured.baseURI = "https://reqres.in";
		RestAssured.basePath = "/api/users";
		pojo1 obj = new pojo1();
		obj.setName("Vikram");	
		obj.setJob("QA");
		Response res = given().contentType(ContentType.JSON).body(obj).when().post();
		System.out.println(res.getBody().asString());
	}
	
	
	

}
