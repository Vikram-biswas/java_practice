package pojoClass;

public class pojo {
	private String name;
	private long phoneNumber;
	private String houseNumber;
	private String address;
	private int id;
	
	pojo(int id, String name, long phoneNumber, String houseNumber, String address){
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.houseNumber = houseNumber;
		this.address = address;
		this.id = id;
	}
	
	public int id() {
    	return id;
    }
	
    public String name() {
    	return name;
    }
    
    public long phoneNumber() {
    	return phoneNumber;
    }
    
    public String houseNumber() {
    	return houseNumber;
    }
    
    public String address() {
    	return address;
    }
	
    public void setName(String name) {
    	this.name = name;
    }
    
    public void setAddress(String address) {
    	this.address = address;
    }
	
}
