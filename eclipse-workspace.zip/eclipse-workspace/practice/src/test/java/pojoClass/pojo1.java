package pojoClass;

public class pojo1 {
	
	String name;
	String job;
	
	
	public void setName(String name) {
		this.name = name;
	}

	public void setJob(String job) {
		this.job = job;
	}
	
}
