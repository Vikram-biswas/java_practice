package lambdaExpression;

public interface functionInterface {
	void draw(int i);

}
