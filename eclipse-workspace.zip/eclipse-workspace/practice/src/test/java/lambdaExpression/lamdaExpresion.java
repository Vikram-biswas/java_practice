package lambdaExpression;

public class lamdaExpresion {

	public static void main(String a[]){
	
        functionInterface val = i->System.out.println(i);
		val.draw(10);
	}

	
}
