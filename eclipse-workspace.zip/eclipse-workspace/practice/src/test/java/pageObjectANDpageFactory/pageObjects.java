package pageObjectANDpageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class pageObjects {

	@FindBy(id = "username") WebElement username;
	@FindBy(id = "password") WebElement password;
	@FindBy(id = "submit") WebElement singin;
	
	
	public WebElement username() {
		return username;
	}
	
	public WebElement password() {
		return password;
	}
	
	public WebElement singin() {
		return singin;
	}
	
}
