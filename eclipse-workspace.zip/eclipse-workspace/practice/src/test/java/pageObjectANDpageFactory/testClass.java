package pageObjectANDpageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.GeckoDriverInfo;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class testClass {
	
	@Test
	public void testmethod() {
		WebDriver driver = new FirefoxDriver();
		pageObjects po = PageFactory.initElements(driver, pageObjects.class);
		driver.get("https://practicetestautomation.com/practice-test-login/");
		po.username().sendKeys("student");
		po.password().sendKeys("Password123");
		po.singin().click();
	}

}
