package customException;

@SuppressWarnings("serial")
public class customException extends Exception{
	
	
	customException(String str){
		super(str);
	}
	

}
