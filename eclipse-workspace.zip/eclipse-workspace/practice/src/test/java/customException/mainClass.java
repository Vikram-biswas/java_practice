package customException;

public class mainClass {

	public static void main(String[] args) throws customException {

		String[] arr = new String[1];
			for (int i = 0; i < 5; i++) {
				arr[i] = "vikram";
				throw new customException("this is my arrayOutOfBound exception");
			}
	}

}
