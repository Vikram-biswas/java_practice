package singleton;

public class singleton {

	static singleton singleInstanse;
	
	singleton(){
		System.out.println("vikram");
	}
	
	
	static public singleton getInstance() {
		
		if(singleInstanse==null) {
			singleInstanse = new singleton();
		}
		return singleInstanse;
	}
	
}
