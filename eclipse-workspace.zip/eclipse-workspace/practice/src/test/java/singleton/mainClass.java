package singleton;

public class mainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		singleton insts1 = singleton.getInstance();
		singleton insts2 = singleton.getInstance();
		singleton insts3 = singleton.getInstance();
		singleton insts4 = singleton.getInstance();
	}

}
