package collections;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class filtering {
	
	String EmpID;
	String EmpName;
	
	filtering(String id, String name){
		this.EmpID = id;
		this.EmpName=name;
	}
	
	static filtering obj1 = new filtering("1","vikram");
	static filtering obj2 = new filtering("2","yogeshwar");
	static List<filtering> list = new ArrayList<filtering>();
	
	public static void main(String args[]) {	
		list.add(obj1);
		list.add(obj2);	
		filterObject();
		
	}
	
	public String getID() {
		return EmpID;
	}
	
	public String EmpName() {
		return EmpName;
	}
	
	
	public static void filterObject() {
		List<filtering> l = list.stream().filter(obj->obj.getID().equals("1")).collect(Collectors.toList());
		l.forEach(val -> System.out.println(val.EmpName()));
	}

}
