package collections;

public class pojoClass {
	
	private int empID;
	private String empName;
	private int empSalary;
	
	pojoClass(int empID, String empName, int empSalary){
		this.empID=empID;
		this.empName=empName;
		this.empSalary=empSalary;
	}
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	

}
