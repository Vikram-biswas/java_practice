package collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.stream.Collectors;

import groovy.lang.Tuple;
import groovy.lang.Tuple2;
import groovy.lang.Tuple3;

public class sorting {
	static List<String> list = Arrays.asList("Myself", "is", "Vikram", "who", "are", "U");
	
	static pojoClass obj1 = new pojoClass(1,"Vikram",5000);
	static pojoClass obj2 = new pojoClass(2,"yogi",4000);
	static pojoClass obj3 = new pojoClass(3,"anand",1000);
	static pojoClass obj4 = new pojoClass(4,"srinivas",3000);
	static pojoClass obj5 = new pojoClass(5,"Sandeep",2000);
	
	public static void main(String a[]) {
	
	}

	// LOGIC 1 - sort arraylist
	public static void sortingList() {
		List<String> list = Arrays.asList("3", "4", "8", "2", "1");
		Collections.sort(list);
		list.forEach(System.out::println);
	}

	// LOGIC 2 - sort ArrayList
	public static void sortingList2() {
		List<String> list = Arrays.asList("3", "4", "8", "2", "1");
		List<String> list1 = list.stream().sorted((a, b) -> a.compareTo(b)).collect(Collectors.toList());

		list1.forEach(System.out::println);

	}

	// LOGIC 3 - sort list by length of each string
	public static void sorting3() {
	

		List<String> list1 = list.stream().sorted(Comparator.comparingInt(String::length).reversed()).toList();
		list1.forEach(System.out::println);

	}

	// LOGIC 4 - sorting map by values wihtout using stream
	public static void sortingMap() {
		Map<String, String> map = new HashMap<>();
		Map<String, String> outmap = new LinkedHashMap<>();
		map.put("name1", "vikram");
		map.put("name2", "yogi");
		map.put("name3", "Yogeshwar");

		Set<String> lsOfKeys = map.keySet();
		List<String> ls = new ArrayList<String>();

		for (String val : lsOfKeys) {
			ls.add(map.get(val));
		}

		List<String> list1 = ls.stream().sorted(Comparator.comparingInt(String::length)).toList();
		for (String val : list1) {
			for (Map.Entry<String, String> val1 : map.entrySet()) {
				if (val1.getValue().equals(val)) {
					outmap.put(val1.getKey(), val);
				}
			}
		}
		outmap.forEach((key, value) -> System.out.println(key + " " + value));
	}
	
	//LOGIC 5 - sorting map by values using stream
	public static void sortingMap1() {
		Map<String, String> map = new HashMap<>();
		map.put("name1", "vikram");
		map.put("name2", "yogi");
		map.put("name3", "Yogeshwar");
		
		Map<String, String> mpp = map.entrySet().stream().sorted(Comparator.comparing(entry -> entry.getValue().length())).collect(LinkedHashMap::new, (a,b)->a.put(b.getKey(),b.getValue()),LinkedHashMap::putAll);
		mpp.forEach((a,b)-> System.out.println(a+" "+b));
	}
	
	//logic 6 - sorting list by string length.
	public static void sortingmap2() {
		Comparator<String> com =(o1,o2) ->{return o1.length()>o2.length()?1:-1;};
		Collections.sort(list, com);
	}
	
	// logic 7
	public static void sortingRecordsBySalary() {
		List<pojoClass> obj = new ArrayList<pojoClass>();
		obj.add(obj1);
		obj.add(obj2);
		obj.add(obj3);
		obj.add(obj4);
		obj.add(obj5);
		
		Comparator<pojoClass> comm = new Comparator<pojoClass>() {
			public int compare(pojoClass i, pojoClass j) {
				if(i.getEmpSalary()>j.getEmpSalary())
				    return 1;
				else
					return -1;
			}
		};		
		Collections.sort(obj, comm);
		obj.forEach(val-> System.out.println(val.getEmpID()+" "+val.getEmpName()+" "+val.getEmpSalary()));		
	}	
	
	//LOGIC 5 - sorting map by values using stream
	public static void sortingMap2() {
		Map<String, String> map = new HashMap<>();
		map.put("name1", "vikram");
		map.put("name2", "yogi");
		map.put("name3", "Yogeshwar");

		Comparator<Map.Entry<String, String>> mapp = new Comparator<Map.Entry<String, String>>() {
			public int compare(Entry<String, String> first, Entry<String, String> second) {
				if(first.getValue().length()>second.getValue().length())
					return 1;
				else			
				    return -1;
			};		
	};
	//map.forEach((a,b)-> System.out.println(a+" "+b));
	
	}

}
