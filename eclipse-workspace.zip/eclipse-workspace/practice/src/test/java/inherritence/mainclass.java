package inherritence;

public class mainclass{

	public static void main(String[] args) {

		BaseInterface obj = new car();
		obj.test();
		BaseInterface obj1 = new truck();
		obj1.test();
		
	
	}

}
