package inherritence;

public interface BaseInterface {
	
	void test();

}
