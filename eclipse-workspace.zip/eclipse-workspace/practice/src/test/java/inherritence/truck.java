package inherritence;

public class truck implements BaseInterface{

	void trucks() {
		System.out.println("this is truck");
	}

	public void test() {
		System.out.println("parent");
	}

}
