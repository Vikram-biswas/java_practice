package inherritence;

public class car implements BaseInterface{
	
	void cars() {
		System.out.println("this is car");
	}


	public void test() {
		System.out.println("child");
		
	}

}
