package com.api.practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Strings {
	
	
	static int[] input = {23,41,64,72,39};
	
	
	public static void main(String args[]) {
		List<Integer> list = new ArrayList<>();
		
		for(int val:input) {
			list.add(val);
		}
		
      List<Integer> lst = list.stream().filter(a-> a.equals(64)).collect(Collectors.toList());
      System.out.println(lst);
		
	}

}
