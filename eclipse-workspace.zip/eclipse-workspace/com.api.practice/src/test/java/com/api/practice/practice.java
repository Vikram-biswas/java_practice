package com.api.practice;



public class practice {

    static String name = "radar";
    static String name1 = "welcome to java";
	
	public static void main(String args[]) {	
		reverseString();
	}
	
	
	public static void polindrome() {
		StringBuffer sb = new StringBuffer();
		
		for(int i=name.length();i>0;i--) {
			String val = name.substring(i-1, i);
			sb.append(val);
		}
		System.out.println(sb);
	}
	
	
	public static void reverseString() {
		StringBuffer sb = new StringBuffer();
		for(int i=name1.length()-1;i>=0;i--){
			String val = name1.substring(i);
			//System.out.println(val);
			//System.out.println(val.hashCode());
			String val1 = val.substring(0);
			
			if(!val1.contains(" ")) {
//				indexes.add(name1.indexOf(val));
//				System.out.println(name1.indexOf(val));
				sb.append(val1);
				System.out.println(sb);
			}
		}
		
		
		
		
	}
	
}
