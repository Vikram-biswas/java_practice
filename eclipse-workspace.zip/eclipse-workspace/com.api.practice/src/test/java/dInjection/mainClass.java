package dInjection;

public class mainClass {

	public static void main(String[] args) {
		//Mysql sql = new Mysql();
		//sql.getDataFromMySql();
		database db = new Mysql();
		

	}

}
