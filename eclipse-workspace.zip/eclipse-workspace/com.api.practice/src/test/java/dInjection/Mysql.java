package dInjection;

public class Mysql implements database{
	
	public void getData() {
		System.out.println("getting data from SQL");
	}

}
