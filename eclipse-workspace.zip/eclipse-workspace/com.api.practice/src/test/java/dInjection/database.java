package dInjection;

public interface database {

	
	void getData();
	


}
