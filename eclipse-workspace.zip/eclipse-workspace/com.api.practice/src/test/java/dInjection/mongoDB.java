package dInjection;

public class mongoDB implements database{
	
	public void getData() {
		System.out.println("getting data from MongoDB");
	}

}
