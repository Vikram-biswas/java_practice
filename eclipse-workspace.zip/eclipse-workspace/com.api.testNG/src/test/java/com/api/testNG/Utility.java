package com.api.testNG;

import static org.testng.Assert.assertEquals;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;

public class Utility {
	ObjectMapper mapper = new ObjectMapper();

public void assertion(Response res) {
	assertEquals(res.statusCode(), 200,"API is successful");
}

public void validateResponseField(Response res, String field, String value) {
	try {
		JsonNode jn = mapper.readTree(res.getBody().asString());
		assertEquals(jn.get("products").get(0).get(field).asText(), value,"the field"+field+"is not validated");		
	} catch (JsonMappingException e) {
		e.printStackTrace();
	} catch (JsonProcessingException e) {
		e.printStackTrace();
	}
	
}

}
