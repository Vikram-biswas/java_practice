package com.api.testNG;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Analyzer implements IRetryAnalyzer{

	int min_retry = 0;
	int max_retry = 3;
	public boolean retry(ITestResult result) {
		if(min_retry<max_retry) {
			min_retry++;
			return true;
		}
		return false;
		
		
	}

}
