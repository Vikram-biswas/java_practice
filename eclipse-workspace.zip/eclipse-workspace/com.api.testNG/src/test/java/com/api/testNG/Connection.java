package com.api.testNG;

import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;



public class Connection extends Utility{
	ObjectMapper om = new ObjectMapper();
	
	public Response get() throws JsonMappingException, JsonProcessingException {
		
		RestAssured.baseURI = "";
		Response res = (Response) RestAssured.given().auth().basic("", "").contentType("application/json").get("https://automationexercise.com/api/productsList").then().extract();
		JsonPath jp = new JsonPath(res.toString());
		JsonNode jn = om.readTree(res.toString());
		
		//Response res = given().accept("application/json").get("https://automationexercise.com/api/productsList").andReturn();
		System.out.println(res.asString());
		assertion(res);
		return res;
		
	}

	
	public void post() {
		
	}
	
	public void put() {
		
	}
}
