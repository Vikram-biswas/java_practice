package com.api.testNG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class Tests extends Connection {

	Utility util = new Utility();
	Response res;

	@DataProvider(name = "fieldDetails")
	public Object[][] testInputs() {

		return new Object[][] { { "name", "Blue Top" }, { "brand", "Polo" } };

	}

	@Test(retryAnalyzer = Analyzer.class)
	public void getMethod() {
		res = get();
		System.out.println("test");

	}

	@Test(dataProvider = "fieldDetails", threadPoolSize=2, invocationCount=2)
	public void validateFields(String field, String value) {
		try {
			util.validateResponseField(res, field, value);
			System.out.println("test1");

		} catch (Exception e) {

		}

	}

}
