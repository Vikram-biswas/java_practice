package singleton;

public class mainClass {

	public static void main(String[] args) {
		
		scenariosClass testObj = scenariosClass.getIntance();
		scenariosClass testObj1 = scenariosClass.getIntance();
		scenariosClass testObj2 = scenariosClass.getIntance();
		scenariosClass testObj3 = scenariosClass.getIntance();
		

		

	}

}
