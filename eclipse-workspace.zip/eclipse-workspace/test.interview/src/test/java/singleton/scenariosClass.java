package singleton;

public class scenariosClass {
	static scenariosClass obj;
	
	scenariosClass(){
 
				System.out.println("this is singleton");  
		}
		
	
	
	public static scenariosClass getIntance() {
		if(obj==null) {
			obj = new scenariosClass();
		}
        return obj;
	}
		

}
