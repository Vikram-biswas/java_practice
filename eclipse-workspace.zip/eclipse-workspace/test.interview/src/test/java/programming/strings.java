package programming;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class strings {



	public static void main(String args[]) {
		tc10();
	}

	// remove numbers from string
	static String tc01 = "vikram0 Bis15was";

	// tc01
	public static void tc01() {
		char[] ca = tc01.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (char val : ca) {
			if (!Character.isDigit(val)) {
				sb.append(val);
			}
		}
		System.out.println(sb);
	}

	// print largest and small size string count
	static String tc02 = "hello vikram I how are you";

	// tc02
	public static void tc02() {
		List<String> list = Arrays.asList(tc02.split(" "));
		int maxCount = 0;
		int minCount = 0;

		for (int i = 0; i < list.size() - 1; i++) {
			if (list.get(i).length() < list.get(i + 1).length() || list.get(i).length() < minCount) {
				if (list.get(i).length() < minCount || minCount == 0) {
					minCount = list.get(i).length();
				}
			} else {
				if (list.get(i).length() > maxCount) {
					maxCount = list.get(i).length();
				}
			}
		}
		System.out.println(minCount + "" + maxCount);
	}

	// print largest and small size string count and string
	static String tc022 = "hello vikram I how are you";

	// tc022
	public static void tc022() {
		List<String> list = Arrays.asList(tc02.split(" "));
		Map<Integer, String> mapp = new HashMap<>();
		for (String val : list) {
			mapp.put(val.length(), val);
		}
		Collection<Integer> val = mapp.keySet();
		List<Integer> val1 = new LinkedList<>(val);
		System.out.println("Max String is :: " + mapp.get(val1.get(val1.size() - 1)) + " and the count is "
				+ val1.get(val1.size() - 1));
		System.out.println("Min String is :: " + mapp.get(val1.get(0)) + " and the count is " + val1.get(0));

	}

	// tc03 - find numeric values
	// fetch the numeric values
	static String tc03 = "vikram 234 my name is 8009";

	public static void tc03() {

		String[] lst = tc03.split(" ");

		for (String val : lst) {
			if (isNumeric(val)) {
				System.out.println(val);
			}
		}
	}

	public static boolean isNumeric(String val) {
		try {
			Integer.parseInt(val);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	// string should be from small size to big size
	static String tc04 = "vikram I have something to tell you";

	public static void tc04() {
		List<String> lst = Arrays.asList(tc04.split(" "));
		Comparator<String> comm = new Comparator<String>() {
			public int compare(String i, String j) {
				return i.length() > j.length() ? 1 : -1;
			}
		};
		Collections.sort(lst, comm);
		System.out.println(lst);
	}

	// string should be start with numbers
	static String tc05 = "vikram 234 my name is 8009";

	public static void tc05() {
		List<String> lst = Arrays.asList(tc05.split(" "));
		// Collections.sort(lst);

		List<String> numberLst = new ArrayList<>();

		for (String val : lst) {
			if (isNumeric(val)) {
				numberLst.add(val);
			}

		}
		for (String val1 : lst) {
			if (!numberLst.contains(val1)) {
				numberLst.add(val1);
			}
		}
		numberLst.forEach(System.out::println);
	}
	
	// find "something" from this string
	static String tc06 = "vikram, I have something to tell you";
	public static void tc06() {
		
		String input = "tell123";
		Pattern p = Pattern.compile(input);
		Matcher m = p.matcher(tc06);
		if(m.find()) {
			System.out.println(m.group());
		}
		
	}
	
	// find "something" from this string
		public static void tc066() {

			String output = tc06.substring(tc06.indexOf("something"), tc06.indexOf("to"));
			System.out.println(output.toUpperCase());
						
		}
	// reverse the string
	static String tc07 = "vikram";
	public static void tc07() {
		
		int length = tc07.length();
		StringBuffer sb = new StringBuffer();
		
		for(int i=1;i<=length;i++) {
			sb.append(tc07.substring(length-i, length-(i-1)));
		}
		System.out.println(sb);
	}
	
	//Check Palindrome: Write a program to check if a given string is a palindrome or not.
	public static void tc08() {
		String input = "radar";
		int len = input.length();
		StringBuffer output = new StringBuffer();
		for(int i=1;i<=len;i++) {
			output.append(input.substring(len-i, len-(i-1)));
		}
		System.out.println(output);
		if(input.contentEquals(output)) {
			System.out.println("Given string is polindrome");
		}else {
			System.out.println("Given string is not polindrome");
		}
		
	}
	
	
	//check the count of vovels and consonents from given string
	public static void tc09() {
		String input = "vikramBiswas";
		char[] ca = input.toCharArray();
		int vovels = 0;
		int consonants = 0;
		
		for(int i=0;i<ca.length;i++) {
			
			if(ca[i]=='a' || ca[i]=='e' || ca[i]=='i' || ca[i]=='o' || ca[i]=='u') {
				vovels++;
			}else {
				consonants ++;
			}
			
			
		}
		System.out.println("vovels count = "+ vovels + " and consonants count = "+consonants);
	}
	
	//Find Duplicate Characters: Write a program to find duplicate characters in a string.
	public static void tc10() {
		String input = "VikramBiswas";		
		for(int i=0;i<input.length();i++) {
			int count = 1;
			for(int j=i+1;j<input.length();j++) {
				if(input.charAt(i)==input.charAt(j)) {
					count++;
				}
			}
			if(count>1){
				System.out.println("character "+ input.charAt(i) + " is having count " + count);
			}
			
		}
	}
	
	
	//Remove Duplicate Characters: Write a program to remove duplicate characters from a string.
	

}
