package dailyStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class javaProgramming {
	static HashMap<String, String> mapp = new HashMap<String, String>();
//	static {
//
//		mapp.put("name", "Vikram");
//		mapp.put("age", "20");
//		mapp.put("height", "5.5");
//		mapp.put("Citizen", "Indian");
//	}
//	
	
   static int[] arr = {3,2,5,5,4};
	public static void main(String[] args) {
		fibonacci(10);

	}
	
	
	// arrange in asc
	public static void logic1() {
		Arrays.sort(arr);
		System.out.println(arr[0]+""+arr[1]+""+arr[2]);
	}
	
	
	// pick input from arr
	public static void logic2(String input) {
		try {
			boolean flag = true;
			int count = 0;
			String output = null ;
			for(int val:arr) {
				String in = Integer.toString(val);
				if(in.equals(input)) {
					count++;
					output = in;
					flag = false;
				}
			}
			if(flag) {
				System.out.println("the input value does not exist in the array");
			}else {
				System.out.println("input value is :: "+output+ " and count  is ::"+count);
			}
		}catch(Exception e){
			
		}
		finally {
			System.out.println("this is finally block");
		}
		
	}

	
	public static void reverseString() {
		String statement = "Hello Vikram Biswas kaise ho";
		ArrayList<String> arr = new ArrayList<String>();
		int beginIndex = 0;
		for(int i=0;i<statement.length();i++) {
			char ch = statement.charAt(i);
			if(ch ==  ' ') {
				arr.add(statement.substring(beginIndex, i));
				beginIndex = i+1;
			}	
			if(i==statement.length()-1) {
				arr.add(statement.substring(beginIndex, i+1));
			}
			
		}
		
		System.out.println(arr);
		
		
	}
	
	public static void getvaluefromMap(String input) {
		
		for(Map.Entry<String, String> entry: mapp.entrySet()) {
			if(entry.getKey().equalsIgnoreCase(input)) {
				System.out.println(input+"::"+entry.getValue());
			}
		}
	}
	
	// write to program to print factorial numbers
	
	public static void factorialNumbers(int input) {
		int fact = 1;
		
		for(int i=input;i>0;i--) {
			fact = fact * i;
		}
		System.out.println(fact);
	}
	
	
	// check the given String is polyndrome or not
	
	public static void poly(String input) {
		
		StringBuffer output = new StringBuffer(input);
		output = output.reverse();
		String out = output.toString();
		if(input.equalsIgnoreCase(out)) {
			System.out.println("Given number is polyndrome");
		}else {
			System.out.println("Given number is not polyndrome");
		}			
	}
	
	// print the fibonacci series
	public static void fibonacci(int input) {
		int prev = 0;
		int next = 1;
		
		for(int i=1;i<input;i++) {

				int sum = prev + next;
				prev = next;
				next = sum;
				System.out.println(sum);
			
			
			
		}
		
		
		
		
		
	}
	

}
