package dailyStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.commons.collections4.bag.SynchronizedSortedBag;

// prime number
//palindrome
//fibanocii
//odd 
//even
//factorial

public class test123 {
	public static void main(String[] args) {

		//prime();

		
		prime();
	}

	public static void test() {

		List<String> arrList = Arrays.asList("Test1", "Test2", "Test3", "Test3");
		Stream<String> strm = arrList.stream();
		System.out.println(strm.distinct().count());

	}

	public static void test1() {
		String logs = "Inktree Realme 12 Pro Plus 5G Flip Cover Card Pockets Wallet & Stand Flip Cover for Realme 12 Pro Plus 5G - Dark Pink Cat";
		String errorMessage = "Realme 12";
		Pattern p = Pattern.compile(errorMessage);
		Matcher m = p.matcher(logs);
		if (m.find()) {
			System.out.println(m.group());
		}
	}

	// palindrome
	static void palindromeString() {
		String input = "radar";
		StringBuffer output = new StringBuffer();
		char[] charArray = input.toCharArray();
		for (int i = charArray.length - 1; i >= 0; i--) {
			output.append(charArray[i]);
		}
		System.out.println(output);
	}

	// print fibanocci series till 20
	static void prime() {
     
		int previousValue = 0;
		int NewValue = 1;
		List<Integer> list = new ArrayList<>();
		for(int i=0;NewValue<20;i++) {
			list.add(previousValue+NewValue);	
			previousValue = NewValue;
			NewValue = list.get(i);
			
		}
		list.forEach(val -> System.out.println(val));	
	}
	
	// factorial for given number
	
	

}
