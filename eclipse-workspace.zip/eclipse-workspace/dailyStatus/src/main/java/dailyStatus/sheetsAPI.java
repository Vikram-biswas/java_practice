package dailyStatus;

import io.restassured.*;
import io.restassured.response.Response;

public class sheetsAPI {
	
	
	public static void api() {
		
		Response res = RestAssured.given().
				queryParam("response_type", "code").
				queryParam("client_id", "811860164810-7go3oje4l35fn88n04sgsuakuvp1oodn.apps.googleusercontent.com").
				queryParam("scope", "https://www.googleapis.com/auth/spreadsheets").
				queryParam("redirect_uri", "https://docs.google.com/spreadsheets")
				.accept("*/*")
				.contentType("*/*").
		        get("https://accounts.google.com/o/oauth2/auth");
		  
		System.out.println(res.getStatusLine());
        System.out.println(res.getHeaders());
  

	}
	
	public static void sheets() {
		
		String token = "ya29.a0AX9GBdWrc6Dr598VlMuTsjMwwiiT3TwzdbPpbgqDZsFHN5Xr2ERrZZUkpa-1dU2l_Gviv7z4FFFF8P4CaiE28mwyStCQI_GAvpDvMiyRK5CwTXMHJSIY2yRu-ukF8iazxMC-zJfeg4I8r_EFBbIo1U7VIAlHaCgYKARMSARMSFQHUCsbCMK-UivAv58NLykxBAb6x3w0163";
		Response res = RestAssured.given().auth().oauth2(token).
				get("https://sheets.googleapis.com/v4/spreadsheets/1dQ7Y-mOf2VcdJoPWgRZYE-2o_Cy1PuBnMI-Yoe_hOBY/values/May 24");
		System.out.println(res.getStatusLine());
        System.out.println(res.getHeaders());
        System.out.println(res.asString());
	}
	
	public static void main(String args[]) {
		
	}

}
