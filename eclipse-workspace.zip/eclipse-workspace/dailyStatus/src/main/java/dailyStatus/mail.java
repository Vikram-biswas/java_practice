package dailyStatus;

public class mail {
	static String name = "vikram";
	static StringBuffer reverse = new StringBuffer();
	static int i=5;
	static boolean flag = true;
	static int chrLength = 0;
	static char[] ch = null;
	static char[] ch1 = new char[6];
	
	
	public static void main(String args[]) {
		System.out.println(getRange4(name));
		//getrange3(name);
	}
	

	
	//Write 5 logics for reverse a string 
	
	
	// logic 1
	public static void getRange(String name) {
		char[] ch = name.toCharArray();
		for(int i=ch.length-1;i>=0;i--) {
			reverse = reverse.append(ch[i]);
		}
		System.out.println(reverse);
	}
	
	
	// logic 2
	public static String getRange2(String name1) {
		if(flag) {
		ch = name1.toCharArray();
		chrLength = name1.length();
		flag = false;
		}
		if(i>=0) {
			ch1[(ch1.length-1)-i] =ch[i]; 
			i--;
			getRange2(name1);
			
		}
		String str = new String(ch1);
		return str;
	}
	
	// logic 3
	public static String getrange3(String name2) {
		String output = new String();
		for(int i=name.length();i>0;i--) {
			output = output.concat(name.substring(i-1,i));
		}	
		return output;
	}
	
	//logic 4
	public static StringBuffer getRange4(String name2) {
		StringBuffer output = new StringBuffer(name2);
		return output.reverse();
		
	}

}
